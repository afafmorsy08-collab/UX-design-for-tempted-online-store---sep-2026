# TEMPTED — React E-Commerce Storefront

TEMPTED is a fully interactive, single-page storefront concept built for an Egyptian women's fashion brand ([@temptedofc](https://www.instagram.com/temptedofc) on Instagram). This version is a typed, component-based React application — built with **React 18**, **TypeScript**, **Tailwind CSS v4**, and **Iconify React** — rather than a static HTML mockup, giving it the architecture and type safety expected of a production front-end.

The store presents an editorial, boutique-style shopping experience: a dark, near-black canvas with a warm wine-red accent, serif display headings, and a fully right-to-left (RTL) Arabic interface, paired with functioning interactions — cart counting, wishlist toggling, an AI shopping-assistant input, and newsletter capture — all driven by real React state.

![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6?logo=typescript&logoColor=white)
![TailwindCSS](https://img.shields.io/badge/Tailwind-v4-06B6D4?logo=tailwindcss&logoColor=white)
![Status](https://img.shields.io/badge/status-prototype-orange)

---

## Table of Contents

- [Overview](#overview)
- [Tech Stack](#tech-stack)
- [Interactive State](#interactive-state)
- [Design System & Theming](#design-system--theming)
- [Page Structure](#page-structure)
- [Imagery](#imagery)
- [Installation](#installation)
- [Project Structure](#project-structure)
- [Customization](#customization)
- [Current Limitations](#current-limitations)
- [Suggested Next Steps](#suggested-next-steps)
- [License](#license)

---

## Overview

Earlier iterations of this project were static HTML/CSS/JS files. This version is a proper **component-based React application**:

- Written entirely in **TypeScript**, with an explicit `Product` interface (`id`, `title`, `subtitle`, `price`, `image`, `tag`) so every catalog entry is type-checked at compile time.
- Icons render through **`@iconify/react`**'s `<Icon />` component (Lucide icon set: `lucide:shopping-bag`, `lucide:heart`, `lucide:truck`, `lucide:search`, etc.) rather than inline SVGs or an icon font.
- Styling runs on **Tailwind CSS v4**, configured through its CSS-first `@theme inline` API rather than a `tailwind.config.js` file — the entire design system is declared and re-themeable directly inside `index.css`.

## Tech Stack

| Layer | Technology |
|---|---|
| UI framework | React 18 |
| Language | TypeScript |
| Styling | Tailwind CSS v4 (`@tailwindcss/vite`) |
| Icons | `@iconify/react` (Lucide icon set) |
| Fonts | Inter (body), Playfair Display (headings), JetBrains Mono (code/mono) |
| Build tool | Vite |

## Interactive State

Four `useState` hooks drive everything clickable on the page:

| State | Purpose | Triggered by |
|---|---|---|
| `cartCount` | Running total shown as a badge on the bag icon | "Add to Bag" button on any product card |
| `wishlist` | Array of saved product IDs | Heart icon on each product card (toggles filled/outline + destructive color) |
| `aiInput` | Text bound to the shopping-assistant input | Manual typing, or tapping a quick-suggestion chip |
| `email` | Text bound to the newsletter field | Footer subscription form |

Both the AI-assistant form and the newsletter form are controlled components with typed `React.FormEvent` handlers that call `e.preventDefault()` and confirm success via `alert()` — a deliberately minimal placeholder marking where a real API call or toast notification should be substituted once a backend exists.

## Design System & Theming

The entire visual identity is defined once as CSS custom properties in `index.css` and mapped into Tailwind's theme layer:

```css
--background: #050606;
--foreground: #F7F4F0;
--tertiary: #6D2938;   /* wine-red brand accent */
--font-heading: "Playfair Display", Georgia, serif;
--font-sans: Inter, sans-serif;
```

These map into Tailwind v4's `@theme inline` block, turning every token into a first-class utility class (`bg-card`, `text-tertiary`, `border-border`, `rounded-lg`, etc.). **Re-skinning the entire store — colors, radius, typography, shadows — requires editing only this one file**, with no changes to component markup.

Two accessibility safeguards are built directly into the stylesheet rather than left to convention:

1. **Automatic foreground pairing** — every filled surface utility (`.bg-card`, `.bg-primary`, `.bg-accent`, `.bg-tertiary`, `.bg-destructive`) is paired in `@layer base` with its own matching foreground color, preventing text from silently inheriting the page's color and becoming invisible against a colored fill.
2. **Legibility-adjusted text tokens** — brand colors used *as text* (`.text-primary`, `.text-tertiary`, `.text-accent`, `.text-destructive`) resolve through separate `--*-text` variants that preserve the brand hue but nudge lightness just enough to clear WCAG AA contrast. These rules sit outside Tailwind's cascade layers intentionally, so they take priority over the utility layer without `!important`.

## Page Structure

1. **Promotional top bar** — free-shipping notice + language switcher (EN/AR)
2. **Sticky header** — cart icon (live count badge), wishlist icon, centered wordmark logo, search button, desktop nav
3. **Hero banner** — full-bleed lifestyle photo, gradient overlay, headline, subcopy, dual CTA buttons
4. **Category grid** — 7 categories (Sportswear, Dresses, Tops, Pants, Coats, Accessories, Hijabs)
5. **New Arrivals** — 5-item responsive product grid with wishlist and add-to-cart controls
6. **Editorial banner** — full-width brand-story section
7. **Best Sellers** — a second 5-item product grid (last item hidden on mobile)
8. **AI Concierge panel** — live-bound input with quick-reply chips and a supporting image
9. **Footer** — brand mark, newsletter form, quick links, customer service links, copyright
10. **Mobile bottom nav** — fixed 5-tab bar (Home, Search, Wishlist, Bag, Account), shown only below the `lg` breakpoint

Every section renders with `dir="rtl"`, and English subtitles/prices are wrapped in nested `dir="ltr"` spans so mixed-direction content (Arabic labels beside "549 EGP") displays correctly.

## Imagery

Product and lifestyle photography is served from hosted image assets (hero banner, sequin top, lace corset, chain jeans, satin maxi dress, blazer dress, tube top, editorial detail shot). Every image reference is a single string field on a `Product` object or an `<img src>` attribute, so swapping photography never requires touching layout code.

## Installation

```bash
# Clone the repository
git clone https://github.com/USERNAME/tempted-react.git
cd tempted-react

# Install dependencies
npm install react react-dom @iconify/react
npm install tailwindcss @tailwindcss/vite

# Run the dev server
npm run dev
```

Register the Tailwind Vite plugin in your `vite.config.ts`, then import the theme stylesheet **once** from your app's entry point:

```ts
// main.tsx
import "./index.css";
```

This import is not optional — `index.css` carries every design token the component's Tailwind class names depend on. Skipping it renders the page completely unstyled.

## Project Structure

```
tempted-react/
├── App.tsx        # Main storefront component (all sections + state)
├── index.css      # Theme tokens, Tailwind v4 config, accessibility layer
└── README.md
```

## Customization

| To change... | Edit... |
|---|---|
| Brand colors, fonts, radius, shadows | `:root` values in `index.css` |
| Product catalog (New Arrivals / Best Sellers) | The `newArrivals` / `bestSellers` arrays in `App.tsx` |
| Category list & icons | The `categories` array in `App.tsx` |
| Icon choice for any element | The `icon` prop on `<Icon icon="lucide:..." />` |
| Hero/editorial photography | The relevant `<img src>` values |

## Current Limitations

This is a **front-end interaction prototype**, not a connected e-commerce backend:

- Cart and wishlist state exist only in React memory and reset on page refresh
- The AI assistant and newsletter forms simulate success with `alert()` rather than calling a real API
- No routing between pages (product detail, cart, checkout) — everything lives in anchor-linked sections on one page
- No payment gateway is integrated

## Suggested Next Steps

- [ ] Replace `alert()` calls with real API requests (newsletter service, AI/chat endpoint)
- [ ] Persist `cart` and `wishlist` state to `localStorage` or a backend session
- [ ] Introduce client-side routing (React Router) for dedicated product detail, cart, and checkout pages
- [ ] Extract the product card, category tile, and section headers into their own reusable component files

## License

This project is for educational and portfolio purposes for the TEMPTED store concept.
